"use client";

import Link from "next/link";
import { Button } from "./ui/button";
import { useContext } from "react";
import { ModalContext } from "./modals/providers";

export default function Navbar() {
  const { setShowSignInModal } = useContext(ModalContext);

  return (
    <div className="border-b">
      <div className="h-14 container mx-auto flex items-center justify-between">
        <Link href="/">Logo</Link>
        <Button onClick={() => setShowSignInModal(true)}>Login</Button>
      </div>
    </div>
  );
}
